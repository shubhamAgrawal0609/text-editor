import { useEffect, useRef, useState } from 'react';
import { FiUpload, FiCalendar, FiSave } from 'react-icons/fi';

export const Editor = ({ content, setContent, setTooltip }) => {
  const editorRef = useRef(null);
  const [localContent, setLocalContent] = useState(content);

  const handleInput = (e) => {
    const newContent = e.target.innerHTML;
    setLocalContent(newContent);
    setContent(newContent);
  };

  const handleSelect = () => {
    const selection = window.getSelection();
    if (!selection.rangeCount) return;

    const range = selection.getRangeAt(0);
    const rect = range.getBoundingClientRect();
    
    setTooltip({
      visible: selection.toString().length > 0,
      x: rect.left + window.scrollX,
      y: rect.top + window.scrollY - 40
    });
  };

  // Handle content deletion and updates
  useEffect(() => {
    const editor = editorRef.current;
    const handleChange = () => {
      setLocalContent(editor.innerHTML);
      setContent(editor.innerHTML);
    };

    if (editor) {
      editor.addEventListener('input', handleChange);
      editor.addEventListener('keydown', handleChange);
      return () => {
        editor.removeEventListener('input', handleChange);
        editor.removeEventListener('keydown', handleChange);
      };
    }
  }, [setContent]);

  return (
    <div className="border-l-4 border-blue-200 pl-4 relative">
      {/* Top Section */}
      

      {/* Editor Area */}
      <div
        ref={editorRef}
        className="min-h-[300px] border border-gray-300 rounded-lg p-4 mb-6 focus:outline-none prose"
        contentEditable
        onInput={handleInput}
        onSelect={handleSelect}
        dangerouslySetInnerHTML={{ __html: localContent }}
        placeholder="Start writing here..."
      />

      {/* Bottom Action Buttons */}
      <div className="flex gap-4  border-t pt-2">
      <button className="px-4 py-2 mr-20 border border-gray-300 rounded-lg flex items-center gap-2">
          <FiSave />
          Save Draft
        </button>
        <button className="px-4 py-2 bg-blue-600 text-white rounded-lg flex items-center gap-2">
          <FiUpload />
          Publish
        </button>
        <button className="px-4 py-2 border border-gray-300 rounded-lg flex items-center gap-2">
          <FiCalendar />
          Schedule
        </button>
       
      </div>
    </div>
  );
};